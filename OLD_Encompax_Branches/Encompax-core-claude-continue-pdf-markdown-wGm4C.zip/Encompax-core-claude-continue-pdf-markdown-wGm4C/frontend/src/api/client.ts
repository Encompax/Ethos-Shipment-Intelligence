/**
 * API base URL - uses /api for all environments
 * Vite dev server proxies /api requests to http://localhost:4000
 * In production, API and frontend are on same origin
 */
const API_BASE = '/api';

export async function fetchDatasources() {
 const res = await fetch(`${API_BASE}/datasources`);
 if (!res.ok) {
   throw new Error(`Failed to fetch datasources: ${res.status}`);
 }
 return res.json();
}

export async function createDatasource(payload: {
 name: string;
 type: string;
 description?: string;
}) {
 const res = await fetch(`${API_BASE}/datasources`, {
   method: "POST",
   headers: { "Content-Type": "application/json" },
   body: JSON.stringify(payload),
 });
 if (!res.ok) {
   throw new Error(`Failed to create datasource: ${res.status}`);
 }
 return res.json();
}

// ── SIL (Shipment Intelligence Layer) ────────────────────────────────────────

const SIL_BASE = '/api/sil';

export async function fetchSilMetrics(from?: string, to?: string) {
  const params = new URLSearchParams();
  if (from) params.set('from', from);
  if (to) params.set('to', to);
  const res = await fetch(`${SIL_BASE}/metrics?${params}`);
  if (!res.ok) throw new Error(`SIL metrics error: ${res.status}`);
  return res.json();
}

export async function fetchSilLiveFeed() {
  const res = await fetch(`${SIL_BASE}/live-feed`);
  if (!res.ok) throw new Error(`SIL live-feed error: ${res.status}`);
  return res.json();
}

export async function fetchSilInTransit() {
  const res = await fetch(`${SIL_BASE}/in-transit`);
  if (!res.ok) throw new Error(`SIL in-transit error: ${res.status}`);
  return res.json();
}

export async function fetchSilExceptions() {
  const res = await fetch(`${SIL_BASE}/exceptions`);
  if (!res.ok) throw new Error(`SIL exceptions error: ${res.status}`);
  return res.json();
}

export async function fetchSilWorkerStatus() {
  const res = await fetch(`${SIL_BASE}/worker-status`);
  if (!res.ok) throw new Error(`SIL worker-status error: ${res.status}`);
  return res.json();
}

// ─────────────────────────────────────────────────────────────────────────────

export async function uploadFile(dataSourceId: number, file: File) {
 const formData = new FormData();
 formData.append('file', file);
 const res = await fetch(`${API_BASE}/uploads?dataSourceId=${dataSourceId}`, {
   method: "POST",
   body: formData,
 });
 if (!res.ok) {
   throw new Error(`Failed to upload file: ${res.status}`);
 }
 return res.json();
}

// ── Shipment Intelligence: Carriers ────────────────────────────────────────

export async function fetchCarrierMetrics() {
  const res = await fetch(`${API_BASE}/shipment/carriers/metrics`);
  if (!res.ok) throw new Error(`Carrier metrics error: ${res.status}`);
  return res.json();
}

export async function fetchCarrierPerformance() {
  const res = await fetch(`${API_BASE}/shipment/carriers/performance`);
  if (!res.ok) throw new Error(`Carrier performance error: ${res.status}`);
  return res.json();
}

// ── Inventory: Lot Tracking ────────────────────────────────────────────────

export async function fetchLotTracking(filters?: { sysmexOnly?: boolean }) {
  const params = new URLSearchParams();
  if (filters?.sysmexOnly) params.set('sysmex', 'true');
  const res = await fetch(`${API_BASE}/inventory/lot-tracking?${params}`);
  if (!res.ok) throw new Error(`Lot tracking error: ${res.status}`);
  return res.json();
}

export async function fetchLotTrackingDetail(lotNumber: string) {
  const res = await fetch(`${API_BASE}/inventory/lot-tracking/${lotNumber}`);
  if (!res.ok) throw new Error(`Lot tracking detail error: ${res.status}`);
  return res.json();
}

export async function createLotTrackingRecord(payload: {
  item_name: string;
  lot_number: string;
  total_quantity: number;
  location: string;
  expiration_date: string;
}) {
  const res = await fetch(`${API_BASE}/inventory/lot-tracking`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Create lot tracking error: ${res.status}`);
  return res.json();
}

// ── Warehouse: Picking Tickets ────────────────────────────────────────────

export async function fetchPickingTickets(filters?: { 
  status?: string;
  operator?: string;
}) {
  const params = new URLSearchParams();
  if (filters?.status) params.set('status', filters.status);
  if (filters?.operator) params.set('operator', filters.operator);
  const res = await fetch(`${API_BASE}/picking/tickets?${params}`);
  if (!res.ok) throw new Error(`Picking tickets error: ${res.status}`);
  return res.json();
}

export async function fetchPickingTicketDetail(ticketId: string) {
  const res = await fetch(`${API_BASE}/picking/tickets/${ticketId}`);
  if (!res.ok) throw new Error(`Picking ticket detail error: ${res.status}`);
  return res.json();
}

export async function scanPickingItem(ticketId: string, payload: {
  scannerId: string;
  lotNumber: string;
  quantityScanned: number;
}) {
  const res = await fetch(`${API_BASE}/picking/tickets/${ticketId}/scan`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Scan picking item error: ${res.status}`);
  return res.json();
}

export async function updatePickingTicketStatus(ticketId: string, status: string) {
  const res = await fetch(`${API_BASE}/picking/tickets/${ticketId}/status`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status }),
  });
  if (!res.ok) throw new Error(`Update picking ticket error: ${res.status}`);
  return res.json();
}

// ── Fulfillment Transactions (PanatrackerGP-aligned) ─────────────────────────

export async function fetchFulfillmentOrders(filters?: {
  status?: string; // pending, picked, verified
  customer?: string;
}) {
  const params = new URLSearchParams();
  if (filters?.status) params.set('status', filters.status);
  if (filters?.customer) params.set('customer', filters.customer);
  const res = await fetch(`${API_BASE}/fulfillment/orders?${params}`);
  if (!res.ok) throw new Error(`Fulfillment orders error: ${res.status}`);
  return res.json();
}

export async function fetchFulfillmentOrderDetail(salesOrderNumber: string) {
  const res = await fetch(`${API_BASE}/fulfillment/orders/${salesOrderNumber}`);
  if (!res.ok) throw new Error(`Fulfillment order detail error: ${res.status}`);
  return res.json();
}

export async function recordPickingTransaction(
  salesOrderNumber: string,
  payload: {
    line_number: number;
    quantity_picked: number;
    lot_number?: string;
    picked_by: string;
    scanner_id?: string;
    notes?: string;
  }
) {
  const res = await fetch(`${API_BASE}/fulfillment/orders/${salesOrderNumber}/pick`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Record picking transaction error: ${res.status}`);
  return res.json();
}

export async function recordVerificationTransaction(
  salesOrderNumber: string,
  payload: {
    line_number: number;
    quantity_verified: number;
    verified_by: string;
    variance_notes?: string;
  }
) {
  const res = await fetch(`${API_BASE}/fulfillment/orders/${salesOrderNumber}/verify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Record verification transaction error: ${res.status}`);
  return res.json();
}

// ── Inventory Management (Warehouse Location Tracking) ──────────────────────

export async function fetchInventoryMovements(filters?: {
  location?: string;
  item?: string;
  lot?: string;
}) {
  const params = new URLSearchParams();
  if (filters?.location) params.set('location', filters.location);
  if (filters?.item) params.set('item', filters.item);
  if (filters?.lot) params.set('lot', filters.lot);
  const res = await fetch(`${API_BASE}/inventory/movements?${params}`);
  if (!res.ok) throw new Error(`Inventory movements error: ${res.status}`);
  return res.json();
}

export async function fetchCurrentInventoryPositions() {
  const res = await fetch(`${API_BASE}/inventory/current-positions`);
  if (!res.ok) throw new Error(`Current inventory positions error: ${res.status}`);
  return res.json();
}

export async function fetchItemTracking(itemNumber: string, lotNumber: string) {
  const res = await fetch(`${API_BASE}/inventory/item-tracking/${itemNumber}/${lotNumber}`);
  if (!res.ok) throw new Error(`Item tracking error: ${res.status}`);
  return res.json();
}

export async function recordInventoryMovement(payload: {
  item_number: string;
  item_description: string;
  lot_number: string;
  quantity_moved: number;
  from_location: string;
  to_location: string;
  from_bin?: string;
  to_bin?: string;
  moved_by: string;
  reason: string;
  unit_of_measure?: string;
  notes?: string;
}) {
  const res = await fetch(`${API_BASE}/inventory/movements`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Record inventory movement error: ${res.status}`);
  return res.json();
}

// ── Cycle Count Transactions (Department-based, Week-filtered) ──────────────

export async function fetchCycleCountDepartments() {
  const res = await fetch(`${API_BASE}/cycle-counts/departments`);
  if (!res.ok) throw new Error(`Cycle count departments error: ${res.status}`);
  return res.json();
}

export async function fetchCycleCountTransactions(department: string, week: number) {
  const res = await fetch(`${API_BASE}/cycle-counts/${department}/${week}`);
  if (!res.ok) throw new Error(`Cycle count transactions error: ${res.status}`);
  return res.json();
}

export async function fetchCycleCountSummary(department: string) {
  const res = await fetch(`${API_BASE}/cycle-counts/summary/${department}`);
  if (!res.ok) throw new Error(`Cycle count summary error: ${res.status}`);
  return res.json();
}